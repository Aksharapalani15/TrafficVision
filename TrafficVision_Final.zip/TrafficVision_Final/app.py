"""TrafficVision - Integrated Streamlit Dashboard."""

from __future__ import annotations

import re
import time
from pathlib import Path

import streamlit as st

from pipeline import DEFAULT_OUTPUT_DIR, process_traffic_video
from vehicle_detection import ModelLoadError, VideoError

UPLOADS_DIR = DEFAULT_OUTPUT_DIR / "uploads"


def _safe_filename(filename: str) -> str:
    cleaned = re.sub(r"[^A-Za-z0-9._-]", "_", Path(filename).name)
    return cleaned or "uploaded_video.mp4"


def _save_uploaded_video(uploaded_file) -> Path:
    UPLOADS_DIR.mkdir(parents=True, exist_ok=True)
    stamp = time.strftime("%Y%m%d_%H%M%S")
    target = UPLOADS_DIR / f"{stamp}_{_safe_filename(uploaded_file.name)}"
    target.write_bytes(uploaded_file.getbuffer())
    return target


def main() -> None:
    st.set_page_config(page_title="TrafficVision", layout="wide")
    st.title("TrafficVision")
    st.write("Upload a traffic video to run vehicle detection, tracking, congestion analysis, and traffic advisory.")

    uploaded_file = st.file_uploader(
        "Upload Traffic Video",
        type=["mp4", "avi", "mov", "mkv", "webm"],
        help="Supported video formats: MP4, AVI, MOV, MKV, WEBM",
    )

    with st.expander("Optional Processing Settings", expanded=False):
        conf_threshold = st.slider(
            "Detection Confidence Threshold",
            min_value=0.10,
            max_value=0.90,
            value=0.25,
            step=0.05,
        )
        max_frames_val = st.number_input(
            "Max Frames to Process (0 = full video)",
            min_value=0,
            value=0,
            step=25,
        )
        use_llm = st.checkbox(
            "Enable Gemini AI Advisory (uses rule-based fallback if API key is missing or unavailable)",
            value=True,
        )

    process_clicked = st.button(
        "Process Video",
        type="primary",
        disabled=(uploaded_file is None),
    )

    if process_clicked:
        if uploaded_file is None:
            st.warning("Please upload a traffic video first.")
            return

        if uploaded_file.size == 0:
            st.error("The uploaded file is empty. Please upload a valid traffic video.")
            return

        status_box = st.empty()
        progress_bar = st.progress(0.0)
        status_box.info("Saving uploaded video and initializing detection model...")

        try:
            input_path = _save_uploaded_video(uploaded_file)

            def on_progress(done: int, total: int) -> None:
                if total > 0:
                    cap_total = min(total, int(max_frames_val)) if max_frames_val > 0 else total
                    frac = min(1.0, done / float(max(1, cap_total)))
                    progress_bar.progress(frac)
                    status_box.info(f"Processing frame {done} / {cap_total}...")
                else:
                    status_box.info(f"Processing frame {done}...")

            result = process_traffic_video(
                video_path=input_path,
                output_dir=DEFAULT_OUTPUT_DIR,
                conf=conf_threshold,
                max_frames=(int(max_frames_val) if max_frames_val > 0 else None),
                use_llm=use_llm,
                progress_callback=on_progress,
            )
            progress_bar.progress(1.0)
            status_box.success(
                f"Processing complete ({result['frames_processed']} frames in {result['processing_seconds']}s)."
            )
            st.session_state["tv_result"] = result
        except VideoError as exc:
            progress_bar.empty()
            status_box.error(f"Video error: {exc}")
        except ModelLoadError as exc:
            progress_bar.empty()
            status_box.error(f"Model loading error: {exc}")
        except Exception as exc:
            progress_bar.empty()
            status_box.error(f"Processing failed: {exc}")

    result = st.session_state.get("tv_result")
    if not result:
        return

    st.divider()

    # 1. Annotated Output Video
    st.subheader("Annotated Output Video")
    video_path = Path(result["output_video_path"])
    if video_path.exists() and video_path.stat().st_size > 0:
        st.video(str(video_path))
        with open(video_path, "rb") as vf:
            st.download_button(
                label="Download Annotated Video",
                data=vf,
                file_name=video_path.name,
                mime="video/mp4" if video_path.suffix == ".mp4" else "video/webm",
            )
    else:
        st.error(f"Annotated output video could not be found at: {video_path}")

    # 2. Traffic Analysis (Member 3)
    analysis = result["analysis"]
    st.subheader("Traffic Analysis")

    col_total, col_status = st.columns(2)
    with col_total:
        st.metric("Total Unique Vehicles Counted", analysis["total_unique_vehicles"])
    with col_status:
        condition = analysis["traffic_condition"]
        status_fn = {"LOW": st.success, "MODERATE": st.warning, "HIGH": st.error}[condition]
        status_fn(f"Traffic Condition: **{condition}**")

    st.write("**Vehicle Category-wise Counts**")
    cls_counts = analysis["class_counts"]
    c1, c2, c3, c4 = st.columns(4)
    c1.metric("Cars", cls_counts["car"])
    c2.metric("Buses", cls_counts["bus"])
    c3.metric("Trucks", cls_counts["truck"])
    c4.metric("Motorcycles", cls_counts["motorcycle"])

    st.caption(
        f"Measured density: {analysis['avg_vehicles_per_frame']} avg vehicles/frame "
        f"across {analysis['frames_processed']} frames. {analysis['threshold_description']}"
    )

    # 3. Traffic Advisory (Member 5)
    st.subheader("Traffic Advisory")
    advisory = result["advisory"]
    if advisory["status"] != "success":
        st.error(f"Could not generate advisory: {advisory.get('note', 'Unknown error')}")
    else:
        priority = advisory["priority"]
        priority_fn = {"Low": st.success, "Medium": st.warning, "High": st.error}.get(priority, st.info)
        priority_fn(f"Priority: **{priority}**")

        st.markdown(f"**Observation:** {advisory['traffic_observation']}")
        st.markdown(f"**Advisory:** {advisory['advisory']}")

        if advisory.get("recommended_actions"):
            st.markdown("**Recommended Actions (for human review):**")
            for action in advisory["recommended_actions"]:
                st.markdown(f"- {action}")

        if advisory.get("source") == "fallback":
            note = advisory.get("note") or "Rule-based fallback advisory displayed."
            st.caption(f"Advisory mode: Rule-based fallback ({note})")
        else:
            st.caption("Advisory mode: AI-generated (Gemini). Suggestions only; final decisions rest with traffic authorities.")


if __name__ == "__main__":
    main()
