"""End-to-end integration tests for TrafficVision_Final."""

from pathlib import Path
import sys

import cv2
import numpy as np
import pytest

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from pipeline import process_traffic_video
from traffic_analysis import analyze_traffic, classify_traffic_condition
from vehicle_counting import VehicleTracker


def test_congestion_thresholds():
    assert classify_traffic_condition(0.0) == ("LOW", "Free")
    assert classify_traffic_condition(4.9) == ("LOW", "Free")
    assert classify_traffic_condition(5.0) == ("MODERATE", "Moderate")
    assert classify_traffic_condition(11.9) == ("MODERATE", "Moderate")
    assert classify_traffic_condition(12.0) == ("HIGH", "Heavy")


def test_tracker_counts_unique_vehicles_without_line_crossing():
    tracker = VehicleTracker(frame_width=1280, frame_height=720, min_hits=3)
    # Simulate one car and one bus moving vertically (not crossing x=640).
    for i in range(4):
        dets = [
            {"class": "car", "bbox": {"x1": 200, "y1": 100 + i * 10, "x2": 300, "y2": 180 + i * 10}},
            {"class": "bus", "bbox": {"x1": 900, "y1": 100 + i * 10, "x2": 1050, "y2": 220 + i * 10}},
        ]
        tracker.update(dets, timestamp=i * 0.04)

    summary = tracker.get_summary()
    assert summary["total_unique_vehicles"] == 2
    assert summary["class_counts"]["car"] == 1
    assert summary["class_counts"]["bus"] == 1
    assert summary["category_counts"]["cars"] == 1
    assert summary["category_counts"]["buses"] == 1


def test_end_to_end_pipeline_on_sample_video_slice(tmp_path, monkeypatch):
    """Run real YOLO + Tracker + Analyzer + Advisory fallback on first 10 frames of traffic.mp4."""
    sample_video = ROOT / "vehicle_detection" / "sample_data" / "traffic.mp4"
    if not sample_video.exists():
        pytest.skip("Sample traffic.mp4 not present")

    monkeypatch.setenv("GEMINI_API_KEY", "")
    result = process_traffic_video(
        video_path=sample_video,
        output_dir=tmp_path,
        max_frames=10,
        use_llm=True,
    )

    out_video = Path(result["output_video_path"])
    assert out_video.exists()
    assert out_video.stat().st_size > 0

    cap = cv2.VideoCapture(str(out_video))
    assert cap.isOpened()
    ok, frame = cap.read()
    cap.release()
    assert ok and frame is not None

    assert result["frames_processed"] == 10
    analysis = result["analysis"]
    assert analysis["total_unique_vehicles"] > 0
    assert analysis["traffic_condition"] in ("LOW", "MODERATE", "HIGH")

    advisory = result["advisory"]
    assert advisory["status"] == "success"
    assert advisory["source"] == "fallback"
    assert advisory["advisory"]
    assert len(advisory["recommended_actions"]) >= 1


def test_end_to_end_pipeline_on_empty_synthetic_video(tmp_path, monkeypatch):
    """Ensure empty road video produces LOW condition and valid fallback advisory without crashing."""
    empty_vid = tmp_path / "empty.mp4"
    writer = cv2.VideoWriter(str(empty_vid), cv2.VideoWriter_fourcc(*"mp4v"), 10.0, (320, 240))
    for _ in range(5):
        writer.write(np.zeros((240, 320, 3), dtype=np.uint8))
    writer.release()

    monkeypatch.setenv("GEMINI_API_KEY", "")
    result = process_traffic_video(video_path=empty_vid, output_dir=tmp_path, use_llm=False)

    assert result["analysis"]["total_unique_vehicles"] == 0
    assert result["analysis"]["traffic_condition"] == "LOW"
    assert result["advisory"]["status"] == "success"
    assert result["advisory"]["source"] == "fallback"
    assert Path(result["output_video_path"]).exists()
