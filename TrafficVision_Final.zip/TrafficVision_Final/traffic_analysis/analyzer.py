"""Simple, explainable congestion analysis based on vehicle detection and tracking results.

Thresholds (average vehicles detected per frame):
- LOW      : avg_vehicles_per_frame < 5.0   (maps to advisory congestion "Free")
- MODERATE : 5.0 <= avg_vehicles_per_frame < 12.0  (maps to advisory congestion "Moderate")
- HIGH     : avg_vehicles_per_frame >= 12.0 (maps to advisory congestion "Heavy")

Only measured counts and per-frame density are used; no speed or unmeasured
traffic metrics are invented.
"""

from __future__ import annotations

from typing import Dict, Tuple

LOW_THRESHOLD = 5.0
HIGH_THRESHOLD = 12.0

CONDITION_TO_ADVISORY = {
    "LOW": "Free",
    "MODERATE": "Moderate",
    "HIGH": "Heavy",
}

THRESHOLD_DOC = (
    f"Based on average detected vehicles per frame: "
    f"< {LOW_THRESHOLD:g} = LOW, "
    f"{LOW_THRESHOLD:g} to < {HIGH_THRESHOLD:g} = MODERATE, "
    f">= {HIGH_THRESHOLD:g} = HIGH."
)


def classify_traffic_condition(avg_vehicles_per_frame: float) -> Tuple[str, str]:
    """Return (dashboard_condition, advisory_congestion_label)."""
    if avg_vehicles_per_frame < LOW_THRESHOLD:
        condition = "LOW"
    elif avg_vehicles_per_frame < HIGH_THRESHOLD:
        condition = "MODERATE"
    else:
        condition = "HIGH"
    return condition, CONDITION_TO_ADVISORY[condition]


def analyze_traffic(tracking_summary: Dict) -> Dict:
    """Compute Member 3 traffic analysis from Member 1+2 tracking summary."""
    frames_processed = int(tracking_summary.get("frames_processed", 0))
    total_detections = int(tracking_summary.get("total_frame_detections", 0))
    total_unique = int(tracking_summary.get("total_unique_vehicles", 0))

    raw_classes = tracking_summary.get("class_counts", {})
    class_counts = {
        "car": int(raw_classes.get("car", 0)),
        "bus": int(raw_classes.get("bus", 0)),
        "truck": int(raw_classes.get("truck", 0)),
        "motorcycle": int(raw_classes.get("motorcycle", 0)),
    }

    raw_categories = tracking_summary.get("category_counts", {})
    category_counts = {
        "cars": int(raw_categories.get("cars", class_counts["car"])),
        "buses": int(raw_categories.get("buses", class_counts["bus"])),
        "trucks": int(raw_categories.get("trucks", class_counts["truck"])),
        "two_wheelers": int(raw_categories.get("two_wheelers", class_counts["motorcycle"])),
    }

    avg_per_frame = round(total_detections / frames_processed, 2) if frames_processed > 0 else 0.0
    traffic_condition, advisory_congestion = classify_traffic_condition(avg_per_frame)

    return {
        "total_unique_vehicles": total_unique,
        "class_counts": class_counts,
        "category_counts": category_counts,
        "traffic_condition": traffic_condition,
        "advisory_congestion": advisory_congestion,
        "avg_vehicles_per_frame": avg_per_frame,
        "frames_processed": frames_processed,
        "threshold_description": THRESHOLD_DOC,
    }
