# TrafficVision

An integrated, end-to-end traffic monitoring and advisory Streamlit application combining:
1. **Member 1 (`vehicle_detection`)**: YOLO11n vehicle detection (`car`, `motorcycle`, `bus`, `truck`).
2. **Member 2 (`vehicle_counting`)**: Multi-frame vehicle tracking, unique ID assignment, and category-wise counting.
3. **Member 3 (`traffic_analysis`)**: Congestion classification (`LOW`, `MODERATE`, `HIGH`) using measured vehicle density.
4. **Member 5 (`traffic_advisory`)**: Short traffic advisory report using Google Gemini API with automatic rule-based fallback.

---

## Project Structure

```text
TrafficVision_Final/
├── app.py                   # Streamlit dashboard entry point
├── pipeline.py              # End-to-end video -> detection -> tracking -> analysis -> advisory
├── requirements.txt         # Combined Python dependencies
├── .env.example             # Optional environment variables for Gemini API
├── README.md                # Setup and execution guide
├── vehicle_detection/       # Member 1: YOLO detector & video utilities (includes yolo11n.pt)
├── vehicle_counting/        # Member 2: VehicleTracker & annotated frame renderer
├── traffic_analysis/        # Member 3: Simple threshold-based congestion analyzer
├── traffic_advisory/        # Member 5: Gemini LLM + rule-based fallback advisory
├── outputs/                 # Saved uploaded & annotated output videos (created at runtime)
└── tests/                   # End-to-end integration tests
```

---

## Windows Setup (PowerShell)

1. Open PowerShell in the `TrafficVision_Final` folder:
   ```powershell
   cd path\to\TrafficVision_Final
   ```

2. Create and activate a virtual environment:
   ```powershell
   python -m venv .venv
   .\.venv\Scripts\Activate.ps1
   ```
   *(If PowerShell blocks script activation, run: `Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass` and try again.)*

3. Install dependencies:
   ```powershell
   python -m pip install --upgrade pip
   pip install -r requirements.txt
   ```

4. *(Optional)* Configure Gemini AI advisory:
   ```powershell
   Copy-Item .env.example .env
   notepad .env
   ```
   Replace `your_api_key_here` with your Google AI Studio `GEMINI_API_KEY`.  
   If you skip this step (or have no internet connection), TrafficVision automatically uses Member 5's built-in rule-based fallback advisory without crashing.

---

## Run the Streamlit Dashboard (Windows)

From inside `TrafficVision_Final` (with `.venv` activated):

```powershell
streamlit run app.py
```

Then in the browser dashboard:
1. Upload a traffic video (for example, `vehicle_detection\sample_data\traffic.mp4`).
2. Click **Process Video**.
3. View the **Annotated Output Video**, **Total Unique Vehicles Counted**, **Vehicle Category-wise Counts**, **Traffic Condition** (`LOW` / `MODERATE` / `HIGH`), and **Traffic Advisory**.

*(Optional)* For a quick demo on long or 4K videos, expand **Optional Processing Settings** in the dashboard and set **Max Frames to Process** (e.g., `100` frames). Leave at `0` to process the full video.

---

## Traffic Condition Thresholds (Member 3)

Traffic condition is determined solely from measured per-frame vehicle detections (no speed or unmeasured statistics are invented):

$$\text{avg\_vehicles\_per\_frame} = \frac{\text{total\_frame\_detections}}{\text{frames\_processed}}$$

| Average Vehicles / Frame | Dashboard Traffic Condition | Member 5 Advisory Input |
|---|---|---|
| `< 5.0` | `LOW` | `Free` |
| `5.0` to `< 12.0` | `MODERATE` | `Moderate` |
| `>= 12.0` | `HIGH` | `Heavy` |

---

## Run Automated Tests

```powershell
python -m pytest tests vehicle_detection\tests traffic_advisory\tests -v
```
